开启plate_node，可通过run plate_node_sub.py来查看车牌号
运行perception_node，会输出校验后的车牌号
