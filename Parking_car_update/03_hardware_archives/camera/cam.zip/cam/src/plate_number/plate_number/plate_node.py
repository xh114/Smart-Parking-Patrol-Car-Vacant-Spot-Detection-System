import json

import rclpy
from parking_robot_msgs.msg import PlateDetection
from rclpy.node import Node
import serial


def clamp(value, lower=0.0, upper=1.0):
    return max(lower, min(upper, value))


class PlateSerialNode(Node):
    def __init__(self):
        super().__init__('plate_serial_node')
        self.declare_parameter('port', '/dev/ttyS9')
        self.declare_parameter('baudrate', 115200)
        self.declare_parameter('timer_period', 0.05)
        self.declare_parameter('default_source_id', 'maixcam_pro')
        self.declare_parameter('legacy_default_confidence', 0.5)

        self.publisher_ = self.create_publisher(PlateDetection, 'plate_detections', 10)

        port = self.get_parameter('port').get_parameter_value().string_value
        baudrate = self.get_parameter('baudrate').get_parameter_value().integer_value
        timer_period = self.get_parameter('timer_period').get_parameter_value().double_value
        self.default_source_id = self.get_parameter('default_source_id').get_parameter_value().string_value
        self.legacy_default_confidence = clamp(
            self.get_parameter('legacy_default_confidence').get_parameter_value().double_value
        )

        try:
            self.ser = serial.Serial(port=port, baudrate=baudrate, timeout=1)
            self.get_logger().info(f'ready to receive plate data from {port} @ {baudrate}')
        except Exception as exc:
            self.get_logger().error(f'failed to open serial port: {exc}')
            raise

        self.timer_ = self.create_timer(timer_period, self.read_plate)

    def _stamp_from_millis(self, timestamp_ms):
        stamp = PlateDetection().stamp
        try:
            total_ms = max(0, int(timestamp_ms))
        except (TypeError, ValueError):
            return self.get_clock().now().to_msg()

        stamp.sec = total_ms // 1000
        stamp.nanosec = (total_ms % 1000) * 1000000
        return stamp

    def _parse_payload(self, line):
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            return {
                'plate_text': line,
                'confidence': self.legacy_default_confidence,
                'source_id': self.default_source_id,
                'timestamp_ms': None,
                'raw_payload': line,
            }

        plate_text = str(payload.get('plate_text', '')).strip().upper()
        return {
            'plate_text': plate_text,
            'confidence': clamp(float(payload.get('confidence', self.legacy_default_confidence))),
            'source_id': str(payload.get('source_id', self.default_source_id)).strip() or self.default_source_id,
            'timestamp_ms': payload.get('timestamp_ms'),
            'raw_payload': line,
        }

    def read_plate(self):
        while self.ser.in_waiting > 0:
            try:
                plate_data = self.ser.readline().decode('utf-8', errors='ignore').strip()
            except Exception as exc:
                self.get_logger().warn(f'failed to decode serial payload: {exc}')
                return

            if not plate_data:
                continue

            payload = self._parse_payload(plate_data)
            if not payload['plate_text']:
                self.get_logger().warn(f'ignoring empty plate payload: {payload["raw_payload"]}')
                continue

            msg = PlateDetection()
            msg.plate_text = payload['plate_text']
            msg.confidence = payload['confidence']
            msg.source_id = payload['source_id']
            msg.raw_payload = payload['raw_payload']
            msg.stamp = self._stamp_from_millis(payload['timestamp_ms'])
            self.publisher_.publish(msg)
            self.get_logger().info(
                f"plate={msg.plate_text} confidence={msg.confidence:.2f} source={msg.source_id}"
            )


def main(args=None):
    rclpy.init(args=args)
    node = PlateSerialNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Node has been interrupted')
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
