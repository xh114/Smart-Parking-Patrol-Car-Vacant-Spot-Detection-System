from collections import defaultdict

import rclpy
from parking_robot_msgs.msg import InspectionRecord, PlateDetection
from rclpy.node import Node
from rclpy.time import Time


def clamp(value, lower=0.0, upper=1.0):
    return max(lower, min(upper, value))


class PlatePerceptionNode(Node):
    def __init__(self):
        super().__init__('plate_perception_node')
        self.declare_parameter('min_confidence', 0.70)
        self.declare_parameter('confirm_count', 3)
        self.declare_parameter('confirm_window_sec', 2.5)
        self.declare_parameter('dedupe_hold_sec', 15.0)
        self.declare_parameter('default_upload_status', 'pending')

        self.min_confidence = clamp(
            self.get_parameter('min_confidence').get_parameter_value().double_value
        )
        self.confirm_count = max(1, self.get_parameter('confirm_count').get_parameter_value().integer_value)
        self.confirm_window_ns = int(
            self.get_parameter('confirm_window_sec').get_parameter_value().double_value * 1e9
        )
        self.dedupe_hold_ns = int(
            self.get_parameter('dedupe_hold_sec').get_parameter_value().double_value * 1e9
        )
        self.default_upload_status = (
            self.get_parameter('default_upload_status').get_parameter_value().string_value
        )

        self.histories = defaultdict(list)
        self.last_published_ns = {}

        self.subscription = self.create_subscription(
            PlateDetection,
            'plate_detections',
            self.plate_callback,
            10,
        )
        self.publisher = self.create_publisher(InspectionRecord, 'inspection_records', 10)
        self.create_timer(1.0, self.cleanup_state)

    def msg_time_ns(self, msg):
        if msg.stamp.sec == 0 and msg.stamp.nanosec == 0:
            return self.get_clock().now().nanoseconds
        return Time.from_msg(msg.stamp).nanoseconds

    def plate_callback(self, msg):
        plate_text = msg.plate_text.strip().upper()
        if not plate_text:
            return

        if msg.confidence < self.min_confidence:
            self.get_logger().debug(
                f'drop low confidence detection plate={plate_text} confidence={msg.confidence:.2f}'
            )
            return

        stamp_ns = self.msg_time_ns(msg)
        history = self.histories[plate_text]
        history.append((stamp_ns, clamp(msg.confidence), msg.source_id))
        self._prune_history(history, stamp_ns)

        if len(history) < self.confirm_count:
            return

        last_publish_ns = self.last_published_ns.get(plate_text)
        if last_publish_ns is not None and stamp_ns - last_publish_ns < self.dedupe_hold_ns:
            return

        self.publish_record(plate_text, history, msg)
        self.last_published_ns[plate_text] = stamp_ns
        self.histories[plate_text] = []

    def _prune_history(self, history, now_ns):
        min_ns = now_ns - self.confirm_window_ns
        while history and history[0][0] < min_ns:
            history.pop(0)

    def publish_record(self, plate_text, history, msg):
        confidences = [item[1] for item in history]
        first_seen_ns = history[0][0]
        last_seen_ns = history[-1][0]

        record = InspectionRecord()
        record.plate_text = plate_text
        record.confidence = sum(confidences) / len(confidences)
        record.stamp = msg.stamp if msg.stamp.sec or msg.stamp.nanosec else self.get_clock().now().to_msg()
        record.first_seen = Time(nanoseconds=first_seen_ns).to_msg()
        record.last_seen = Time(nanoseconds=last_seen_ns).to_msg()
        record.source_id = msg.source_id
        record.image_id = ''
        record.observation_count = len(history)
        record.confirmed = True
        record.upload_status = self.default_upload_status
        self.publisher.publish(record)

        self.get_logger().info(
            'confirmed plate=%s confidence=%.2f observations=%d source=%s'
            % (record.plate_text, record.confidence, record.observation_count, record.source_id)
        )

    def cleanup_state(self):
        now_ns = self.get_clock().now().nanoseconds
        for plate_text in list(self.histories.keys()):
            self._prune_history(self.histories[plate_text], now_ns)
            if not self.histories[plate_text]:
                del self.histories[plate_text]

        expire_before = now_ns - self.dedupe_hold_ns * 4
        for plate_text, last_ns in list(self.last_published_ns.items()):
            if last_ns < expire_before:
                del self.last_published_ns[plate_text]


def main(args=None):
    rclpy.init(args=args)
    node = PlatePerceptionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Perception node interrupted')
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
