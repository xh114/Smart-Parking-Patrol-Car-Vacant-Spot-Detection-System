import math
import time
from typing import Optional

import numpy as np
import rclpy
from geometry_msgs.msg import TransformStamped
from nav_msgs.msg import OccupancyGrid, Odometry, MapMetaData
from rclpy.node import Node
from rclpy.qos import HistoryPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import Imu, LaserScan
from std_msgs.msg import Header
from tf2_ros import TransformBroadcaster


def quaternion_to_yaw(q) -> float:
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def clamp(value: float, minimum: float, maximum: float) -> float:
    return max(min(value, maximum), minimum)


class ImuLidarMapper(Node):
    def __init__(self):
        super().__init__('imu_lidar_mapping')

        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10,
        )

        self.declare_parameter('imu_topic', '/imu/data_raw')
        self.declare_parameter('scan_topic', '/scan')
        self.declare_parameter('map_frame', 'map')
        self.declare_parameter('odom_frame', 'odom')
        self.declare_parameter('base_frame', 'base_link')
        self.declare_parameter('resolution', 0.05)
        self.declare_parameter('width', 400)
        self.declare_parameter('height', 400)
        self.declare_parameter('origin_x', -10.0)
        self.declare_parameter('origin_y', -10.0)
        self.declare_parameter('fake_motion', False)
        self.declare_parameter('fake_linear_x', 0.1)
        self.declare_parameter('fake_angular_z', 0.0)
        self.declare_parameter('map_publish_interval',0.5)

        self.imu_topic = self.get_parameter('imu_topic').value
        self.scan_topic = self.get_parameter('scan_topic').value
        self.map_frame = self.get_parameter('map_frame').value
        self.odom_frame = self.get_parameter('odom_frame').value
        self.base_frame = self.get_parameter('base_frame').value
        self.resolution = float(self.get_parameter('resolution').value)
        self.width = int(self.get_parameter('width').value)
        self.height = int(self.get_parameter('height').value)
        self.origin_x = float(self.get_parameter('origin_x').value)
        self.origin_y = float(self.get_parameter('origin_y').value)
        self.use_fake_motion = bool(self.get_parameter('fake_motion').value)
        self.fake_linear_x = float(self.get_parameter('fake_linear_x').value)
        self.fake_angular_z = float(self.get_parameter('fake_angular_z').value)

        self.pose_x = 0.0
        self.pose_y = 0.0
        self.pose_theta = 0.0
        self.last_time: Optional[float] = None
        self.last_imu_time: Optional[float] = None

        self.log_odds = np.zeros((self.height, self.width), dtype=np.float32)
        self.occupancy_grid = OccupancyGrid()
        self._initialize_map()

        self.tf_broadcaster = TransformBroadcaster(self)
        self.odom_pub = self.create_publisher(Odometry, 'imu_lidar_odom', qos)
        self.map_pub = self.create_publisher(OccupancyGrid, 'map', qos)

        self.create_subscription(Imu, self.imu_topic, self.imu_callback, qos)
        self.create_subscription(LaserScan, self.scan_topic, self.scan_callback, qos)
        self.create_timer(0.1, self.timer_callback)

        self.get_logger().info(
            f'ImuLidarMapper started. imu_topic={self.imu_topic}, scan_topic={self.scan_topic}, '
            f'fake_motion={self.use_fake_motion}'
        )

    def _initialize_map(self):
        self.occupancy_grid.header.frame_id = self.map_frame
        self.occupancy_grid.info = MapMetaData()
        self.occupancy_grid.info.resolution = self.resolution
        self.occupancy_grid.info.width = self.width
        self.occupancy_grid.info.height = self.height
        self.occupancy_grid.info.origin.position.x = self.origin_x
        self.occupancy_grid.info.origin.position.y = self.origin_y
        self.occupancy_grid.info.origin.position.z = 0.0
        self.occupancy_grid.info.origin.orientation.w = 1.0
        self.occupancy_grid.data = [-1] * (self.width * self.height)

    def imu_callback(self, msg: Imu) -> None:
        if msg.orientation is None:
            return
        self.pose_theta = quaternion_to_yaw(msg.orientation)
        now = self.get_clock().now().nanoseconds * 1e-9
        self.last_imu_time = now

    def scan_callback(self, msg: LaserScan) -> None:
        if self.last_imu_time is None:
            self.get_logger().warn('Waiting for IMU orientation before mapping.')
            return

        self._update_pose_by_fake_motion()
        self._update_map(msg)
        self._publish_map(msg.header.stamp)
        self._publish_odometry(msg.header.stamp)
        self._broadcast_tf(msg.header.stamp)

    def timer_callback(self) -> None:
        now = time.time()
        if self.last_time is None:
            self.last_time = now
            return
        self.last_time = now

    def _update_pose_by_fake_motion(self) -> None:
        if not self.use_fake_motion:
            return

        now = time.time()
        if self.last_time is None:
            self.last_time = now
            return

        dt = now - self.last_time
        dx = self.fake_linear_x * dt
        dtheta = self.fake_angular_z * dt
        self.pose_x += dx * math.cos(self.pose_theta)
        self.pose_y += dx * math.sin(self.pose_theta)
        self.pose_theta += dtheta
        self.pose_theta = math.atan2(math.sin(self.pose_theta), math.cos(self.pose_theta))
        self.last_time = now

    def _update_map(self, scan: LaserScan) -> None:
        max_range = max(scan.ranges) if scan.ranges else 0.0
        for i, r in enumerate(scan.ranges):
            if not math.isfinite(r):
                continue
            if r <= scan.range_min or r > scan.range_max:
                continue

            angle = scan.angle_min + i * scan.angle_increment + self.pose_theta
            x = self.pose_x + r * math.cos(angle)
            y = self.pose_y + r * math.sin(angle)
            start_ix, start_iy = self._world_to_map(self.pose_x, self.pose_y)
            end_ix, end_iy = self._world_to_map(x, y)
            self._trace_ray(start_ix, start_iy, end_ix, end_iy)

    def _trace_ray(self, x0: int, y0: int, x1: int, y1: int) -> None:
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        x, y = x0, y0
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy

        while True:
            self._update_cell_free(x, y)
            if x == x1 and y == y1:
                self._update_cell_occupied(x, y)
                break
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x += sx
            if e2 < dx:
                err += dx
                y += sy

    def _update_cell_free(self, mx: int, my: int) -> None:
        if not self._in_bounds(mx, my):
            return
        self.log_odds[my, mx] = clamp(self.log_odds[my, mx] - 0.4, -4.0, 4.0)

    def _update_cell_occupied(self, mx: int, my: int) -> None:
        if not self._in_bounds(mx, my):
            return
        self.log_odds[my, mx] = clamp(self.log_odds[my, mx] + 0.85, -4.0, 4.0)

    def _world_to_map(self, x: float, y: float) -> tuple[int, int]:
        mx = int((x - self.origin_x) / self.resolution)
        my = int((y - self.origin_y) / self.resolution)
        return mx, my

    def _in_bounds(self, mx: int, my: int) -> bool:
        return 0 <= mx < self.width and 0 <= my < self.height

    def _publish_map(self, stamp: Header.stamp) -> None:
        grid = np.full((self.height, self.width), -1, dtype=np.int8)
        grid[self.log_odds > 0.0] = 100
        grid[self.log_odds < 0.0] = 0
        self.occupancy_grid.header.stamp = self.get_clock().now().to_msg()
        self.occupancy_grid.data = grid.flatten().tolist()
        self.map_pub.publish(self.occupancy_grid)

    def _publish_odometry(self, stamp: Header.stamp) -> None:
        odom = Odometry()
        odom.header.stamp = self.get_clock().now().to_msg()
        odom.header.frame_id = self.map_frame
        odom.child_frame_id = self.odom_frame
        odom.pose.pose.position.x = float(self.pose_x)
        odom.pose.pose.position.y = float(self.pose_y)
        odom.pose.pose.position.z = 0.0

        qz = math.sin(self.pose_theta / 2.0)
        qw = math.cos(self.pose_theta / 2.0)
        odom.pose.pose.orientation.z = qz
        odom.pose.pose.orientation.w = qw

        if self.use_fake_motion:
            odom.twist.twist.linear.x = float(self.fake_linear_x)
            odom.twist.twist.angular.z = float(self.fake_angular_z)

        self.odom_pub.publish(odom)

    def _broadcast_tf(self, stamp) -> None:
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = self.map_frame
        t.child_frame_id = self.odom_frame
        t.transform.translation.x = float(self.pose_x)
        t.transform.translation.y = float(self.pose_y)
        t.transform.translation.z = 0.0
        t.transform.rotation.z = math.sin(self.pose_theta / 2.0)
        t.transform.rotation.w = math.cos(self.pose_theta / 2.0)
        self.tf_broadcaster.sendTransform(t)


def main(args=None):
    rclpy.init(args=args)
    node = ImuLidarMapper()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
